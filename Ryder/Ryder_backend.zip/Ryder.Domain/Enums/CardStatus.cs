﻿namespace Ryder.Domain.Enums
{
    public enum CardStatus
    {
        Active = 1,
        Expired = 2,
        InActive = 3,
    }
}