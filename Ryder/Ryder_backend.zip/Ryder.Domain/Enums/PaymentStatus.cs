﻿namespace Ryder.Domain.Enums
{
    public enum PaymentStatus
    {
        Initiated = 1,
        Pending = 2,
        Failed = 3,
        Successful = 4
    }
}