﻿namespace Ryder.Domain.Enums
{
    public enum RiderAvailabilityStatus
    {
        Available = 1,
        Unavailable = 2
    }
}