﻿namespace Ryder.Domain.Enums
{
    public enum PaymentType
    {
        None = 0,
        Card = 1,
        BankTransfer = 2
    }
}