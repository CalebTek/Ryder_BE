﻿namespace Ryder.Infrastructure.Common
{
    public class Constants
    {
        public const string InternalServerErrorMessage = "A server error occured we are working on it";
    }
}