﻿using Ryder.Domain.Entities;
using Ryder.Domain.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Ryder.Application.Order.Query.OrderProgress
{
    public class OrderProgressResponse
    {  
        public string Status { get; set; }

    }
}
