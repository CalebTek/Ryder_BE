﻿namespace Ryder.Application.Authentication.Command.ForgetPassword
{
    public class ForgetPasswordResponse
    {
        public string Email { get; set; }
    }
}